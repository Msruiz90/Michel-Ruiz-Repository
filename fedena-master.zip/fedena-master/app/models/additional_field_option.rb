class AdditionalFieldOption < ActiveRecord::Base

  belongs_to :additional_field

end
